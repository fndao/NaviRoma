/**
 * 
 */
package mean;

/**
 * @author NDAO Fatou
 *
 */
public class GeneSample {
	
	private String geneName;
	
	private String [] sumScoreSample;

	/**
	 * @return the sumScoreSample
	 */
	public String[] getsumScoreSample() {
		return sumScoreSample;
	}

	/**
	 * @param sumScoreSample the sumScoreSample to set
	 */
	public void setsumScoreSample(String[] sumScoreSample) {
		this.sumScoreSample = sumScoreSample;
	}

	/**
	 * @return the geneName
	 */
	public String getgeneName() {
		return geneName;
	}

	/**
	 * @param geneName the geneName to set
	 */
	public void setgeneName(String geneName) {
		this.geneName = geneName;
	}
	
	
	

}
