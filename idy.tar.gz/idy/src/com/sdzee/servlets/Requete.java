package com.sdzee.servlets;

import javax.servlet.http.HttpServlet;

import java.io.IOException;

//import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;



public class Requete extends HttpServlet {
	public static final String CHAMP_Maps = "module";
	public static final String CHAMP_data  = "fichier";
	public static final String CHAMP_box = "box";
	public void doGet( HttpServletRequest request, HttpServletResponse response ) 
	throws ServletException, IOException{
	

		
		//response.setContentType("text/html");
		this.getServletContext().getRequestDispatcher( "/WEB-INF/Requete.jsp" ).forward( request, response );	
	}

	public void doPost( HttpServletRequest request, HttpServletResponse response ) 
		throws ServletException, IOException{
		
        /* Récupération des champs du formulaire. */
        
        String module = request.getParameter( CHAMP_Maps );
        System.out.println(module);
        String box =  request.getParameter(CHAMP_box);
        System.out.println(box);
        String fichier = request.getParameter( CHAMP_data );
        System.out.println(fichier);
        System.out.println("je suis la!!!");
        System.out.println("je suis encore la!!!");
        /*
       // try {
        //    validationEmail( fichier );
        //} catch (Exception e) {
            // Gérer les erreurs de validation ici. } */

       
		
		this.getServletContext().getRequestDispatcher( "/WEB-INF/Requete.jsp" ).forward( request, response ); 
       }
	
	
}	