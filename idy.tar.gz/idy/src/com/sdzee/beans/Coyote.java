package com.sdzee.beans;

public class Coyote {
	private String nom; //proprietes obligatoirement non public
	private String prenom;
	private boolean genius;

	public String getNom() { // au moins un constructeur public "obligatoirement"
		return this.nom;
	}

	public String getPrenom() {
		return this.prenom;
	}

	public boolean isGenius() {
		return this.genius;
	}

	public void setNom( String nom ) {// des getteurs et setteurs obligatoirement
		this.nom = nom;
	}

	public void setPrenom( String prenom ) {
		this.prenom = prenom;
	}

	public void setGenius( boolean genius ) {
		//fatou. Coyote fait toujours preuve d'une ingéniosité hors du commun, c'est indéniable ! Bip bip... */
		this.genius = true;
	}
}